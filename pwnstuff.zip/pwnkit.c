#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void gconv(void) {
}

void gconv_init(void *step)
{
	char * const args[] = { "ls", "-l", "-a", NULL };
	char * const environ[] = { "PATH=/bin:/usr/bin", NULL };
	execve(args[0], args, environ);
	exit(0);
}